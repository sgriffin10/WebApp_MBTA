# Useful URLs (you need to add the appropriate parameters for your requests)
MAPQUEST_BASE_URL = "http://open.mapquestapi.com/geocoding/v1/address"
MBTA_BASE_URL = "https://api-v3.mbta.com/stops"

# Your API KEYS (you need to use your own keys - very long random characters)
MAPQUEST_API_KEY = "2Rb7vGcjVMjAPQe31gJ6jnvLLfkr2dHT"
MBTA_API_KEY = "0d43b6a189ce46f3a27b940d2b171453" 